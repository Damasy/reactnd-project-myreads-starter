import React from 'react';
import './App.css';
import MainPage from './MainPage';

const BooksApp = () => {
  return (
    <div>
      <MainPage/>
    </div>
  )
}

export default BooksApp
